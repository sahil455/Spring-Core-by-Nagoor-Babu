package com.sahil.beans;

public class Employee {
	private String eid,ename;
	private Account acc;
	//private Address addr;
	
	public String getEid() {
		return eid;
	}
	public Employee(String eid, String ename, Account acc) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.acc = acc;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Account getAcc() {
		return acc;
	}
	public void setAcc(Account acc) {
		this.acc = acc;
	}
	

	public void details()
	{
		System.out.println("Emplyoee Details\n-------------");
		System.out.println("Eid          :"+eid);
		System.out.println("EName        :"+ename);
		System.out.println("Account Details\n--------------");
		System.out.println("Account Id   :"+acc.getAccno());
		System.out.println("Account Name :"+acc.getAccname());
		System.out.println("Address Details\n--------------");
		//System.out.println("Flat No   	 :"+addr.getFno());
		//System.out.println("Street Name  :"+addr.getStreet());


	}
}
