package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.HelloBean;

public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("/com/sahil/resourcses/ApplicatioContext.xml");
		HelloBean hb=(HelloBean)context.getBean("helloBean");
		//hb.setName("sahil");
		System.out.println(hb.sayHello());
	}

}
