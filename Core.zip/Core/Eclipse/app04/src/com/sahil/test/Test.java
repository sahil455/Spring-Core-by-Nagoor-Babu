package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.bean.HelloBean;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext con=new ClassPathXmlApplicationContext("/com/sahil/resource/applicationContext.xml");
		HelloBean hb=(HelloBean)con.getBean("HoboBean");
		System.out.println(hb.sayHobo());
	}
	

}
