package com.sahil.beans;

public class Course {

	private String cId,cName;
	private int cCost;
	public Course(String cId, String cName, int cCost) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.cCost = cCost;
	}
	
	public void getCourseDetails()
	{
		System.out.println("Course Details\n----------------");
		
		System.out.println("Course Id   :" +cId);
		System.out.println("Course Name :" +cName);
		System.out.println("Course Cost :" +cCost);
		//System.out.println();
	}
	
}
