package com.sahil.beans;

public class User {

	private String uname,upwd;
	private int uage;
	private String uemail,umobile;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public int getUage() {
		return uage;
	}
	public void setUage(int uage) {
		this.uage = uage;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getUmobile() {
		return umobile;
	}
	public void setUmobile(String umobile) {
		this.umobile = umobile;
	}
	public void details()
	{
		System.out.println("Details\n----------------");
		System.out.println("UNAME   :"+uname);
		System.out.println("UPWD    :"+upwd);
		System.out.println("UAGE    :"+uage);
		System.out.println("UEMAIL  :"+uemail);
		System.out.println("UMPBILE :"+umobile);
	}
}
