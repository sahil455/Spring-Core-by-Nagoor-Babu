package com.sahil.validator;

import java.util.Properties;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.sahil.beans.User;

public class UserValidatio implements Validator {

	private Resource resource;
	
	
	

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	@Override
	public boolean supports(Class<?> cls) {
		// TODO Auto-generated method stub
		return User.class.equals(cls);
	}

	@Override
	public void validate(Object obj, Errors error) {
		
		User user=(User)obj;
		try {
		Properties prop= PropertiesLoaderUtils.loadProperties(resource);
		
		if(user.getUname()== null || user.getUname().equals(""))
		{
			error.rejectValue("uname", "error.uname.required",prop.getProperty("error.uname.required"));
		}
		if(user.getUpwd()== null || user.getUpwd().equals(""))
		{
			error.rejectValue("upwd", "error.upwd.required",prop.getProperty("error.upwd.required"));
		}
		else {
			if(user.getUpwd().length()<6)
			{			
				error.rejectValue("upwd", "error.upwd.minLength.required",prop.getProperty("error.upwd.minLength.required"));
				
			}
			if(user.getUpwd().length()>10)
			{			
				error.rejectValue("upwd", "error.upwd.maxLength.required",prop.getProperty("error.upwd.maxLength.required"));
				
			}
		}
		
		if(user.getUage()== 0)
		{
			error.rejectValue("uage", "error.uage.required",prop.getProperty("error.uage.required"));
		}
		else
		{
			if(user.getUage()< 18 || user.getUage()> 25)
			{
				error.rejectValue("uage", "error.uage.range.required",prop.getProperty("error.uage.range.required"));

			}
		}
		if(user.getUemail()== null || user.getUemail().equals(""))
		{
			error.rejectValue("uemail", "error.uemail.email.required",prop.getProperty("error.uemail.email.required"));
		}
		else
		{
			if(!(user.getUemail().contains("@")))
			{
				error.rejectValue("uemail", "error.uemail.emailValidate.required",prop.getProperty("error.uemail.emailValidate.required"));

			}
		}
		if(user.getUmobile()== null || user.getUmobile().equals(""))
		{
			error.rejectValue("umobile", "error.umobile.required",prop.getProperty("error.umobile.required"));
		}
		else
		{
			if(user.getUmobile().length()<10) {
				error.rejectValue("umobile", "error.umobile.valid.required",prop.getProperty("error.umobile.valid.required"));

			}
		}
	}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
