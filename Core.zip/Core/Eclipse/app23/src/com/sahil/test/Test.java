package com.sahil.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;

import com.sahil.beans.User;
import com.sahil.validator.UserValidatio;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		User u=(User)co.getBean("userBean");
		u.details();
		
		System.out.println();
		UserValidatio userValidator=(UserValidatio)co.getBean("userValidatior");
		Map<String,String> m=new HashMap<String,String>();
		MapBindingResult res=new MapBindingResult(m, "com.sahil.beans.User");
		userValidator.validate(u, res);
		List<ObjectError> list=res.getAllErrors();
		for(ObjectError error:list)
		{
			System.out.println(error.getDefaultMessage());
		}
	}

}
