package com.sahil.core;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Locale local=new Locale("it","IT");
		NumberFormat nf=NumberFormat.getInstance(local);
		System.out.println(nf.format(123455.8675757));
		
		DateFormat df=DateFormat.getDateInstance(1,local);
		System.out.println(df.format(new Date()));

		ResourceBundle rb=ResourceBundle.getBundle("abc",local);
		System.out.println(rb.getString("Welcome"));
	}

}
