package com.sahil.beans;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Student {
	private String sid,sname;
	private Address saddr;
	private List<String> squal;
	private Set<String> scourse;
	private Map<String,String> scourse_and_sfaculty;
	private Properties scourse_and_cost;
	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Address getSaddr() {
		return saddr;
	}

	public void setSaddr(Address saddr) {
		this.saddr = saddr;
	}
	
	
   public Set<String> getScourse() {
		return scourse;
	}

	public void setScourse(Set<String> scourse) {
		this.scourse = scourse;
	}

public List<String> getSqual() {
		return squal;
	}

	public void setSqual(List<String> squal) {
		this.squal = squal;
	}

	
	
public Map<String, String> getScourse_and_sfaculty() {
		return scourse_and_sfaculty;
	}

	public void setScourse_and_sfaculty(Map<String, String> scourse_and_sfaculty) {
		this.scourse_and_sfaculty = scourse_and_sfaculty;
	}
	

public Properties getScourse_and_cost() {
		return scourse_and_cost;
	}

	public void setScourse_and_cost(Properties scourse_and_cost) {
		this.scourse_and_cost = scourse_and_cost;
	}

public void getStuDetails()
   {
	   System.out.println("STUDENT DETAILS\n---------------\n");
	   System.out.println("STUDENT ID   :"+sid);
	   System.out.println("STUDENT Name :"+sname);
	   System.out.println("STUDENT QUALIFICATION DETAILS :"+squal);
	  
	   System.out.println("STUDENT COURSES DETAILS :"+scourse);

	   
	   System.out.println("STUDENT_COURSES_AND_FACULTIES DETAILS :" +scourse_and_sfaculty);
	   System.out.println("STUDENT_COURSES_AND_COST DETAILS :" +scourse_and_cost);

	   System.out.println("STUDENT ADDRESS DETAILS\n---------------\n");
	   System.out.println("PNO          : "+saddr.getPno());
	   System.out.println("STREET       : "+saddr.getStreet());
	   System.out.println("CITY         : "+saddr.getCity());
	   System.out.println("STATE        : "+saddr.getState());
	   System.out.println("COUNTRY      : "+saddr.getCountry());

   }
   
	
}
