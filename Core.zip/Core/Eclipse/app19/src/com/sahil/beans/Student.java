package com.sahil.beans;

public class Student {
 
	private String sid,sname;
	private Course course;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public void details()
	{
		System.out.println("Student Details\n-------------");
		System.out.println("SID   :" +sid);
		System.out.println("SNAME :"+sname);
		System.out.println("Course Details\n-------------");
		System.out.println("CID   :"+course.getCid());
		System.out.println("CNAME :"+course.getCname());

	}
	
}

