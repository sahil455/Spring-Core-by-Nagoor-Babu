package com.sahil.beans;

public class HelloBean {
	static {
		System.out.println("Helobean loading");
	}
	public HelloBean()
	{
		System.out.println("Helobean Instantiation");

	}
	
	public String sayHello()
	{
		return "Hello";
	}
	public static HelloBean getInstant()
	{
		System.out.println("Helobean Static Instantiation");
		return new HelloBean();

	}
	
}
