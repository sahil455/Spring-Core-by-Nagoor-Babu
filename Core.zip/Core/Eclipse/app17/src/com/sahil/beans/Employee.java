package com.sahil.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

public class Employee {
	private String eid,ename;
	private Account acc;
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Account getAcc() {
		return acc;
	}
	//@Required
	@Autowired(required=true)
	public void setAcc(Account acc) {
		this.acc = acc;
	}
	public void details()
	{
		System.out.println("Emplyoee Details\n-------------");
		System.out.println("Eid          :"+eid);
		System.out.println("EName        :"+ename);
		System.out.println("Account Details\n--------------");
		System.out.println("Account No   :"+acc.getCcno());
		System.out.println("Account Name :"+acc.getAccname());
		//System.out.println("Address Details\n--------------");
	}
}
