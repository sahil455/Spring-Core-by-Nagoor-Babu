package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.Employee;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext con=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
	
	Employee e=(Employee)con.getBean("emp");
	e.details();
	
	
	
	}

}
