package com.sahil.PostProcessor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.sahil.beans.Account;

public class AccountPostProcessor implements BeanPostProcessor {
	
	@Override
	public Object postProcessBeforeInitialization(Object bean,String name ) throws BeansException
	{
		
		Account acc=(Account) bean;
		if(acc.getAccType()==null)
		{
			acc.setAccType("Saving");
		}
		
		
		return acc;
	}
	
	@Override
	public Object postProcessAfterInitialization(Object bean,String name ) throws BeansException
	{
		Account acc=(Account) bean;
		String email=acc.getAccHolderEmail();
		if(!email.contains("@"))
		{
			email=email+"@gmail.com";
			acc.setAccHolderEmail(email);
		}
		String mob=acc.getAccHolderMobileNo();
		if(!mob.startsWith("91-"))
		{
			mob="91-" +mob;
			acc.setAccHolderMobileNo(mob);
		}
		return acc;
	}
	
	

}
