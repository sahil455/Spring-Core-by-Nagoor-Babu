package com.sahil.beans;

public class Account {
	
	private String accNo,accHolderName,accType;
	private int bal;
	private String accHolderEmail,accHolderMobileNo;
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public int getBal() {
		return bal;
	}
	public void setBal(int bal) {
		this.bal = bal;
	}
	public String getAccHolderEmail() {
		return accHolderEmail;
	}
	public void setAccHolderEmail(String accHolderEmail) {
		this.accHolderEmail = accHolderEmail;
	}
	public String getAccHolderMobileNo() {
		return accHolderMobileNo;
	}
	public void setAccHolderMobileNo(String accHolderMobileNo) {
		this.accHolderMobileNo = accHolderMobileNo;
	}
 public void getDetails()
 {
	 System.out.println("Account Details\n-------------");
	 System.out.println("Account NO               :"+accNo);
	 System.out.println("Account Holder Name      :"+accHolderName);
	 System.out.println("Account Type             :"+accType);
	 System.out.println("Account Balance          :"+bal);
	 System.out.println("Account Holder Email     :"+accHolderEmail);
	 System.out.println("Account Holder Mobile No :"+accHolderMobileNo);


 }
 
}
