package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.CurrentAccount;
import com.sahil.beans.SavingAccount;
import com.sahil.factory.AccountFactory;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		AccountFactory savingAccountFactory=(AccountFactory)co.getBean("savingAccountFactory");
		SavingAccount savingAccount= (SavingAccount)savingAccountFactory.getAccount();
		savingAccount.createAccount();
		savingAccount.deleteAccount();
		
		AccountFactory currentAccountFactory=(AccountFactory)co.getBean("currentAccountFactory");
		CurrentAccount currentAccount=(CurrentAccount)currentAccountFactory.getAccount();
		currentAccount.createAccount();
		currentAccount.deleteAccount();
	}

}
