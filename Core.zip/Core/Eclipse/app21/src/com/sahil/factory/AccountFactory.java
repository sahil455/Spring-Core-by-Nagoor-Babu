package com.sahil.factory;

import com.sahil.beans.Account;

public abstract class AccountFactory {

	
		public abstract Account getAccount();
		

}
