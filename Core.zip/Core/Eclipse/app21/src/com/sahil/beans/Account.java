package com.sahil.beans;

public interface Account {
	public void createAccount();
	public void deleteAccount();
}
