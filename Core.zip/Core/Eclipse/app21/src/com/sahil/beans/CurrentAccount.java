package com.sahil.beans;

public class CurrentAccount implements Account{
	public void createAccount()
	{
		System.out.println("Current Account Created");
	}
	public void deleteAccount()
	{
		System.out.println("Current Account Deleted");

	}

}
