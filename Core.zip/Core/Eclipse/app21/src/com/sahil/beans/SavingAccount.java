package com.sahil.beans;

public class SavingAccount implements Account {
	public void createAccount()
	{
		System.out.println("Saving Account Created");
	}
	public void deleteAccount()
	{
		System.out.println("Saving Account Deleted");

	}

}
