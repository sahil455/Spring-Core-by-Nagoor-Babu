package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.HelloBean;
import com.sahil.beans.WelcomeBean;
import com.sahil.beans.WishBeans;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    ApplicationContext con=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");;
		/*WishBeans ws=(WishBeans)con.getBean("wishBean");
		System.out.println(ws.wish());
		*/
		HelloBean hb=(HelloBean)con.getBean("helloBean");
		System.out.println(hb.sayHello());
	
		WelcomeBean wb=(WelcomeBean)con.getBean("welcomeBean");
		System.out.println(wb.sayWelcome());
	}
	
	
	

}
