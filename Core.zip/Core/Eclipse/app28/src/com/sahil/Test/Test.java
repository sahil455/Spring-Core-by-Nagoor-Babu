package com.sahil.Test;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import com.sahil.calci.Calculator;

public class Test {
	public static void main(String[] args) {
		Calculator c=new Calculator();
		StandardEvaluationContext con=new StandardEvaluationContext(c);
		ExpressionParser p=new SpelExpressionParser();
		
		Expression e1= p.parseExpression("n1");
		e1.setValue(c, 10);
		
		Expression e2= p.parseExpression("n2");
		e2.setValue(c, 11);
		
		System.out.println("Num1 :"+c.getN1());
		System.out.println("Num2 :"+c.getN2());

		System.out.println("Add :"+c.add());
		System.out.println("Mul :"+c.mul());

	}
}
