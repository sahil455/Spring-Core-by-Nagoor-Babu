package com.sahil.beans;

public class Student {
	private Branch branch;
/*	public Student(Branch br) {
		// TODO Auto-generated constructor stub
		this.br=br;
	}*/
	public String  getStuDetails()
	{
		return "SAHIL";
	}
	public Branch getBranch() {
		return branch;
	}
	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	

}
