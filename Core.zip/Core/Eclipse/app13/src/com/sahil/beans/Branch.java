package com.sahil.beans;

public class Branch {
	private Student student;
	/*public Branch(Student stu) {
		// TODO Auto-generated constructor stub
		this.stu=stu;
	}*/
	
	public String getBranchName()
	{
		return "COMPUTERS";
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	
}
