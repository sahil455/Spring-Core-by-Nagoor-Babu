package com.sahil.test;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.sahil.beans.DBBean;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("String.profiles.active", "development");
		GenericXmlApplicationContext co=new GenericXmlApplicationContext();
		//co.refresh();
		co.load("/com/sahil/resources/applicationContext-development.xml","/com/sahil/resources/applicationContext-production.xml");
		co.refresh();
		DBBean d=(DBBean)co.getBean("dbBean ");
		d.details();
	
	
	}

}
