package com.sahil.beans;

public class DBBean {

	private String driverClass,driverUrl,dbuserName,dbPassword;

	public String getDriverClass() {
		return driverClass;
	}

	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}

	public String getDriverUrl() {
		return driverUrl;
	}

	public void setDriverUrl(String driverUrl) {
		this.driverUrl = driverUrl;
	}

	public String getDbuserName() {
		return dbuserName;
	}

	public void setDbuserName(String dbuserName) {
		this.dbuserName = dbuserName;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	public void details()
	{
		System.out.println("DB DETAILS\n---------------");
		System.out.println("DRIVER CLASS NAME :"+driverClass);
		System.out.println("DRIVER URL        :"+driverClass);
		System.out.println("DRIVER USER NAME  :"+driverClass);
		System.out.println("DRIVER PASSWORD   :"+driverClass);

	}
}
