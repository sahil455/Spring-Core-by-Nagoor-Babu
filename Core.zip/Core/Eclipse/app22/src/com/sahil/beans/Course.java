package com.sahil.beans;

public class Course {
	private String cid,cname;

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	public void details() {
		System.out.println("Details\n--------------");
		System.out.println("CID   "+cid);
		System.out.println("CNAME :"+cname);

	}
}
