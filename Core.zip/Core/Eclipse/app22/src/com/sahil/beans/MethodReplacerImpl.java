package com.sahil.beans;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class MethodReplacerImpl implements MethodReplacer {

	@Override
	public Object reimplement(Object arg0, Method arg1, Object[] arg2) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("Details\n--------------");
		System.out.println("CID   : 222");
		System.out.println("CNAME : PYTHON");
		return null;
	}

}
