package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.Account;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		Account acc=(Account)co.getBean("account");
		acc.createAccount();
		acc.deleteAccount();
		acc.searchAccount();
		acc.updateAccount();
	
	
	}

}
