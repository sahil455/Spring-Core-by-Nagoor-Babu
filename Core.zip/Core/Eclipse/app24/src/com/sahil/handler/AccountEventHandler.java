package com.sahil.handler;

import org.springframework.context.ApplicationListener;

import com.sahil.events.AccountEvent;

public class AccountEventHandler implements ApplicationListener<AccountEvent> {

	@Override
	public void onApplicationEvent(AccountEvent ae) {
		// TODO Auto-generated method stub
		ae.generateLog();

	}

}
