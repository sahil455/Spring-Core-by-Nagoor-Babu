package com.sahil.beans;

import com.sahil.publisher.AccountEventPublisher;

public class Account {
	private AccountEventPublisher publisher;
	
	
	public void setPublisher(AccountEventPublisher publisher) {
		this.publisher = publisher;
	}
	public void createAccount() {
		System.out.println("Account creation");
		publisher.publish("Account Created");
	}
	public void searchAccount() {
		System.out.println("Account Searched");
		publisher.publish("Account Searched");

	}
	public void updateAccount() {
		System.out.println("Account Updated");
		publisher.publish("Account updated");

	}
	public void deleteAccount() {
		System.out.println("Account deleted");
		publisher.publish("Account deleted");

	}
	
}
