package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sahil.beans.WelcomeBean;
import com.sahil.config.AppConfig;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext con=new AnnotationConfigApplicationContext(AppConfig.class);
		WelcomeBean wb=(WelcomeBean)con.getBean("welcomeBean");
		System.out.println(wb.getWelomsmsg());
		
	}

}
