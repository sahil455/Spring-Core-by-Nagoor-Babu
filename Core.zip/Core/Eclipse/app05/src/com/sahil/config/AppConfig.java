package com.sahil.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sahil.beans.WelcomeBean;

@Configuration
public class AppConfig {
	
	@Bean
	public WelcomeBean welcomeBean()
	{
		WelcomeBean wel= new WelcomeBean();
		wel.setMsg("oooo");
		 return wel;
	}
	
}
