package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.I18NBean;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		I18NBean i=(I18NBean) co.getBean("i18bean");
		i.display();
	}

}
