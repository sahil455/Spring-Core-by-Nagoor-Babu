package com.sahil.beans;

public class Course {
private String cid,cname;

public Course(String cid, String cname) {
	super();
	this.cid = cid;
	this.cname = cname;
}
public String getCid() {
	return cid;
}
public String getCname() {
	return cname;
}
}
