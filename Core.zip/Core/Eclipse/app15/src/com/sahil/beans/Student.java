package com.sahil.beans;

public class Student {
	private String sid,sname;
	private Course course;
	public Student(String sid, String sname, Course course) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.course = course;
	}
	public void getDetails()
	{
		System.out.println("DETAILS----------------");
		System.out.println("Student ID   :"+sid);
		System.out.println("Student Name :"+sname);
		System.out.println("COURSE DETAILS----------------");
		System.out.println("Course ID   :"+course.getCid());
		System.out.println("Course Name :"+course.getCname());

	}
	
}
