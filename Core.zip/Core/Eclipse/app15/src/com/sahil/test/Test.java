package com.sahil.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.beans.Student;

public class Test {
	public static void main(String[] ad)
	{
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		Student s=(Student)co.getBean("stuBean");
		s.getDetails();
	}
	

}
