package com.sahil.beans;

public class Employee {

	private String eid,ename;
	private float  esal;
	private String addr;
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public float getEsal() {
		return esal;
	}
	public void setEsal(float esal) {
		this.esal = esal;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public void getEmpDetails()
	{
			System.out.println("Employee Details-----");
			System.out.println("Employee no       :"+eid);
			System.out.println("Employee name     :"+ename);
			System.out.println("Employee salary   :"+esal);
			System.out.println("Employee address  :"+addr);

	}

}
