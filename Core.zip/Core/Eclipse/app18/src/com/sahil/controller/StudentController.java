package com.sahil.controller;

import com.sahil.dto.Student;

public interface StudentController 
{
	public void addStudent();
	public void searchStudent();
	//public Student getStudent(String sid);
	public void updateStudent();
	public void deleteStudent();


}
