package com.sahil.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahil.controller.StudentController;

public class Test {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		ApplicationContext co=new ClassPathXmlApplicationContext("/com/sahil/resources/applicationContext.xml");
		StudentController studentController=(StudentController)co.getBean("studentController");
	
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			System.out.println("1 ADD");
			System.out.println("2 SEARCH");
			System.out.println("3 UPDATE");
			System.out.println("4 DELETE");
			System.out.println("5 EXIT");
			System.out.println("Your Option[1,2,3,4,5] :");
			int op=Integer.parseInt(br.readLine());
			switch(op)
			{
				case 1:
					studentController.addStudent();
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				case 5:
					System.out.println("Thank you");
					System.exit(0);
					break;
				default :
					System.out.println("Enterv option");
			}


		}
	}

}
