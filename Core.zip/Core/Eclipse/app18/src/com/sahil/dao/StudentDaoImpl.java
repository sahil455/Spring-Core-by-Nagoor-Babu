package com.sahil.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sahil.dto.Student;

import oracle.jdbc.pool.OracleDataSource;

@Repository("studentDao")
public class StudentDaoImpl implements StudentDao {

	
	@Autowired
	private OracleDataSource dataSource;
	@Override
	public String add(Student student) {
		// TODO Auto-generated method stub
		String status="";
		
		try {
			
			Connection con=dataSource.getConnection();
			PreparedStatement pst=con.prepareStatement("select * from student where SID=?");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public Student search(String sid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String update(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delete(String sid) {
		// TODO Auto-generated method stub
		return null;
	}

}
